import 'package:flutter/material.dart';

class AppColors{
  static const primary = Color(0xffFBD512);
  static const font = Color(0xffD8D8D8);
  static const font2 = Color(0xff373737);
  static const disableFont = Color(0xffFA7A7A7);
  static const disableButton = Color(0xff303030);
  static const background = Color(0xffffffff);
  static const Black = Color(0xff00000);
  static const White = Color(0xffffffff);



}